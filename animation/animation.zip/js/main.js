$(document).ready(function(){
    $('.slide').on('mouseenter', function(){
        $(this).addClass('over');
    });
});